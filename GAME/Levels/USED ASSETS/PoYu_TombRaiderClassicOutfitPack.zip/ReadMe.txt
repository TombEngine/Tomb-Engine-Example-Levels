-------------------------------------------
Another Classic Outfit (with 4 different color choices)
-------------------------------------------

All meshes are made by me. Textures are modified from TRU.

Whole new body of Lara with whole New meshes for body(arms, hands, legs, head), also with better lighting reaction.
but every meshes are still under the 255 vertix limit.

Please DO NOT recalculate normal any mesh in Strpix, it will cause bad lighting. 
If you really want to use this head mesh for your outfit, please use sapper's tool to weight normal it after you replace mesh.

To use different look, copy/paste all stuff from AnotherClassic.wad to your wad first,
then cover it again with *color.wad 

Hope you can enjoy this outfit and the new face!

If you use this outfit on your level, please give me a credit, thanks.
If you use or modify my meshes or textures for your item, please give me a credit as well.

                                                               PoYu Chen 08/Jan/2011